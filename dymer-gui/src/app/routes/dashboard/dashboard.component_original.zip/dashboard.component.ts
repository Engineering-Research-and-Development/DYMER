import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
   EventEmitter,
  NgZone,
  Output,
  OnDestroy,
  OnInit,
  inject,
} from '@angular/core';
import { CdkDrag, CdkDragStart } from '@angular/cdk/drag-drop';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatListModule } from '@angular/material/list';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { SettingsService } from '@core';
import { MtxAlertModule } from '@ng-matero/extensions/alert';
import { MtxProgressModule } from '@ng-matero/extensions/progress';
import { Subscription } from 'rxjs';
import { DashboardService } from './dashboard.service';
import { TranslateModule } from '@ngx-translate/core';
import { MtxGridColumn, MtxGridModule } from '@ng-matero/extensions/grid';
import { TranslateService } from '@ngx-translate/core';
import { PageHeaderComponent } from '@shared';
import { MatIconModule } from '@angular/material/icon';
import { KpiMinicardComponent } from '@shared';
import { RouterOutlet } from '@angular/router';
import { ApexOptions } from 'apexcharts';
import ApexCharts from "apexcharts";
import {StatsCardComponent} from '@shared';
import { MatDialog } from '@angular/material/dialog';
import { RelationsDialogComponent } from './dashboard.relations-dialog.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [DashboardService],
  standalone: true,
  imports: [
    StatsCardComponent,
    MatButtonModule,
    MatCardModule,
    MatChipsModule,
    MatListModule,
    MatGridListModule,
    MatTableModule,
    MatTabsModule,
    MtxProgressModule,
    MtxAlertModule,
    TranslateModule,
    MtxGridModule,
    MatIconModule

  ],
})
export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy {
 
  private readonly ngZone = inject(NgZone);
  private readonly settings = inject(SettingsService);
  private readonly dashboardSrv = inject(DashboardService);
  private readonly translate = inject(TranslateService);
  
  private dragging = false;
    onDragStart(event: CdkDragStart) {
    this.dragging = true;
  }

  constructor(
    private dymerService: DashboardService,
    private dialog: MatDialog
    ) {}

   charts = this.dashboardSrv.getCharts();
   chart2?: ApexCharts;


   modelsIndexesColumns: MtxGridColumn[] = [
      {
        header: this.translate.stream('index'),
        field: 'index',
        sortable: true,
        minWidth: 100,
        width: '100px',
      },
      {
        header: this.translate.stream('model'),
        field: 'model.title',
        sortable: true,
        minWidth: 100,
        width: '100px',
      },
      {
        header: this.translate.stream('entities'),
        field: 'count',
        sortable: true,
        minWidth: 100,
        width: '100px',
      },
      {
        header: this.translate.stream('action'),
        field: 'action',
        minWidth: 80,
        width: '80px',
        pinned: 'right',
        type: 'button',
        buttons: [
          {
            type: 'icon',
            icon: 'assignment_returned',
            tooltip: this.translate.stream('export'),
            click: index => this.exportEntities(index),
          },
          {
            type: 'icon',
            color: 'warn',
            icon: 'delete',
            tooltip: this.translate.stream('delete_entities'),
            click: index => this.deleteAllEntitiesByIndex(index),
          },
          {
            type: 'icon',
            color: 'warn',
            icon: 'delete_forever',
            tooltip: this.translate.stream('delete_entities_and_index'),
            click: index => this.deleteAllEntitiesAndIndexByIndex(index),
          },
        ],
      },
  ];
  templatesIndexesColumns: MtxGridColumn[] = [
    {
      header: this.translate.stream('index'),
      field: 'index',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('previewList'),
      field: 'templates.teaserlist.title',
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('fullContent'),
      field: 'templates.fullcontent.title',
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('generalPreview'),
      field: 'templates.teaser.title',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('previewMap'),
      field: 'templates.teasermap.title',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
  ];
  entitiesIndexesColumns: MtxGridColumn[] = [
    {
      header: this.translate.stream('index'),
      field: '_index',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('title'),
      field: '_source.title',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('user'),
      field: '_source.properties.owner.uid',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('date'),
      field: '_source.properties.created',
      type: 'date',
      sortable: true,
      minWidth: 100,
      width: '100px',
    },
    {
      header: this.translate.stream('visibility'),
      field: '_source.properties.visibility',
      minWidth: 100,
      width: '100px',
      type: 'tag',
      tag: {
        0: {text: 'Public', color: 'green-95'},
        1: {text: 'Private', color: 'orange-95'},
        2: {text: 'Restricted', color: 'red-95'},
      },
    },
    {
      header: this.translate.stream('status'),
      field: '_source.properties.status',
      minWidth: 100,
      width: '100px',
      type: 'tag',
      tag: {
        1: {text: 'Published', color: 'green-95'},
        2: {text: 'Unpublished', color: 'orange-95'},
        3: {text: 'Draft', color: 'red-95'},
      },
    },
  ];

  info: any = [];
  uuid: any = [];
  allIndexes: any = [];
  allForms: any = [];
  allTemplates: any = [];
  allEntities: any = [];
  entitiesList: any = [];
  latestCreatedEntities: any = [];
  latestUpdatedEntities: any = [];
  allCountRelations: any = 0;
  relationsData: any;

  notifySubscription = Subscription.EMPTY;
  isShowAlert = true;

  ngOnInit() {
    this.notifySubscription = this.settings.notify.subscribe(opts => {

      this.getInfo();
      this.getAllIndexesAndEntities();
      this.getLatestEntities();
    });
  }

  ngAfterViewInit() {
    this.ngZone.runOutsideAngular(() => this.initDashboard());
    
  }


   initCharts() {
   
    //this.chart2 = new ApexCharts(document.querySelector('#chart2'), this.charts[0]);
   // this.chart2?.render();

    //this.updateCharts();
  }
  
  updateCharts() {
    const isDark = this.settings.getThemeColor() == 'dark';
    this.chart2?.updateOptions({
      chart: {
        foreColor: isDark ? '#ccc' : '#333',
      },
      plotOptions: {
        radar: {
          polygons: {
            strokeColors: isDark ? '#5a5a5a' : '#e1e1e1',
            connectorColors: isDark ? '#5a5a5a' : '#e1e1e1',
            fill: {
              colors: isDark ? ['#2c2c2c', '#222'] : ['#f2f2f2', '#fff'],
            },
          },
        },
      },
      tooltip: {
        theme: isDark ? 'dark' : 'light',
      },
    });
  }
  ngOnDestroy() {

    this.notifySubscription.unsubscribe();
  }

  initDashboard() {
    this.loadRelationsData();
    this.initCharts();
  }

  /*Caricamento dati relazioni per contatore e grafo*/
  loadRelationsData(){
    this.dymerService.allRelations().subscribe((allRelations: any) => {
      this.relationsData = allRelations;
      this.allCountRelations = 0;
      for(let relation of allRelations.data) {
        this.allCountRelations += relation.doc_count;
      }
    });
  }

  openRelationsGraph() {
    if (this.relationsData) {
      this.dialog.open(RelationsDialogComponent, {
        width: '900px',
        data: this.relationsData
      });
    }
  }
  /*Export delle entità*/
  exportEntities(index: any){
    this.dymerService.exportEntities(index).subscribe((exp: any) => {
      let d = new Date();
      let date = d.toISOString().split('T')[0].replace(/-/g, '_');
      let time = d.toTimeString().split(' ')[0].replace(/:/g, '_');
      let dataFile = JSON.stringify(exp)
      let blob = new Blob([dataFile], { type: 'application/json' });
      let linkElement = document.createElement('a');
      let url = window.URL.createObjectURL(blob);
      let filename = `${index.index}_catalogue_${date}_${time}.json`
      linkElement.setAttribute('href', url);
      linkElement.setAttribute("download", filename);
      let clickEvent = new MouseEvent("click", {
          "view": window,
          "bubbles": true,
          "cancelable": false
      });
      linkElement.dispatchEvent(clickEvent);
    });
  }
  /*Eliminazione dell'indice e di tutte le entità relative*/
  deleteAllEntitiesAndIndexByIndex(index: any){
    this.dymerService.deleteAllEntitiesAndIndexByIndex(index).subscribe((ret: any) => {
      console.log("Deletion all entities and index by index done ===> ", ret);
    });
  }
  /*Eliminazione di tutte le entità*/
  deleteAllEntitiesByIndex(index: any){
    this.dymerService.deleteAllEntitiesByIndex(index).subscribe((ret: any) => {
      console.log("Deletion all entities by index done ===> ", ret);
    });
  }
  /*Acquisizione delle info di base del Dymer*/
  getInfo() {
    this.dymerService.uuid().subscribe((uuid: any) => {
      this.uuid = uuid.data.uuid;
    });
    this.dymerService.info().subscribe((info: any) => {
      this.info = info;
    });
  }
  /*Acquisizione di tutti gli indici ed entità*/
  getAllIndexesAndEntities() {
    this.dymerService.allStats().subscribe((allStats: any) => {
      this.allIndexes = allStats.data.indices.filter((value : any) => value.index !== 'entity_relation');
      console.log(allStats.data.indices);
      let entitiesList = [];
      let res = allStats.data;
      let countrela = 0;
      entitiesList = res.indices;
      let lisrl = entitiesList.filter(function (el:any) {
          return el.index == "entity_relation";
      })[0];
      
      if (lisrl != undefined) {
          countrela = lisrl["count"];
      }
      entitiesList = entitiesList.filter(function (el:any) {
          return el.index !== "entity_relation";
      });
      this.allEntities = res.total - countrela;
      this.dymerService.allForms().subscribe((allForms: any) => {
        this.allForms = allForms.data;
        entitiesList.forEach(function (elEnt: any) {
          elEnt.model = {
              'title': "x",
              'exsist': false
          }
          allForms.data.forEach(function (elTEm: any ) {
            (elTEm.instance).forEach(function (elTEmIN: any) {
                if (elEnt.index == elTEmIN._index) {
                    elEnt.model.title = elTEm.title;
                    elEnt.model.exsist = true;
                }
            });
          });
        });
      });
      this.dymerService.allTemplates().subscribe((allTemplates: any) => {
        this.allTemplates = allTemplates.data;
        entitiesList.forEach(function (elEnt: any) {
          elEnt.templates = {
              "fullcontent": {
                  'title': "",
                  'exsist': false
              },
              "teaserlist": {
                  'title': "",
                  'exsist': false
              },
              "teasermap": {
                  'title': "",
                  'exsist': false
              },
              "teaser": {
                  'title': "",
                  'exsist': false
              }
          }
          allTemplates.data.forEach(function (elTEm: any) {
              (elTEm.instance).forEach(function (elTEmIN: any) {
                  if (elEnt.index == elTEmIN._index) {
                      (elTEm.viewtype).forEach(function (elVTEmIN: any) {
                          elEnt.templates[elVTEmIN.rendertype].exsist = true;
                          elEnt.templates[elVTEmIN.rendertype].title = elTEm.title;
                      });
                  }
              });
          });
        });
      });
      this.entitiesList = entitiesList;
    });
  }
  /*Acquisizione delle ultime entità create e aggiornate*/
  getLatestEntities() {
    this.dymerService.latestEntities(["properties.created:desc"]).subscribe((latestEntities: any) => {
      this.latestCreatedEntities = latestEntities.data;
    });
    this.dymerService.latestEntities(["properties.changed:desc"]).subscribe((latestEntities: any) => {
      this.latestUpdatedEntities = latestEntities.data;
    });
  }

  onAlertDismiss() {
    this.isShowAlert = false;
  }
}
