import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { ApexOptions } from 'apexcharts';
 
import { SessionService } from '../sessions/session.service';
import { ApiService } from '@core/services/api.service';


@Injectable()
export class DashboardService {
  private apiService = inject(ApiService);
  private baseContextPath = this.apiService.endpoints.dashboard;

   







  constructor(private httpClient: HttpClient,
    private sessionService: SessionService
  ) { }
  uuid(): any {
    return this.httpClient.get(this.baseContextPath.uuid, { withCredentials: true });
  }
  info(): any {
    return this.httpClient.get(this.baseContextPath.info);
  }
  allStats(): any {
    return this.httpClient.get(this.baseContextPath.allStats);
  }
  allForms(): any {
    return this.httpClient.get(this.baseContextPath.allForms, { withCredentials: true });
  }
  allTemplates(): any {
    return this.httpClient.get(this.baseContextPath.allTemplates);
  }
  allRelations(): any {
    return this.httpClient.get(this.baseContextPath.allRelations);
  }
  exportEntities(index: any): any {
    const params = new HttpParams().set(
      'query',
      JSON.stringify({ 'index': index })
    );
    return this.httpClient.post(this.baseContextPath.exportEntities, params, { withCredentials: true });
  }
  deleteAllEntitiesAndIndexByIndex(index: any): any {
    const params = {'index': index.index};
    return this.httpClient.get(this.baseContextPath.deleteAllEntitiesAndIndexByIndex, {params, withCredentials: true });
  }
  deleteAllEntitiesByIndex(index: any): any {
    const params = {'index': index.index};
    return this.httpClient.get(this.baseContextPath.deleteAllEntitiesByIndex, {params, withCredentials: true });
  }
  latestEntities(sort: any []): any {
    const body = {
      query: {
        query: {
          bool: {
            must_not: {
              match: {
                _index: 'entity_relation',
              },
            },
          },
        },
      },
      qoptions: {
          relations: false,
          fields: { "include": ["title", "properties"] },
          size: 30,
          sort: sort
      }
    };
    return this.httpClient.post(this.baseContextPath.entitiesSearch, body, { withCredentials: true });
  }
  getCharts() {
     let dati: any[]=[];
     let valori: any[] = [];
     this.allStats().subscribe((allStats: any) => {
        allStats.data.indices.forEach((value : any) =>{
          if(value.index != 'entity_relation') {
            dati.push(value.index);
            valori.push(value.count);
          }
           
        });
        console.log(allStats.data.indices);
     });

 

    let  charts: ApexOptions[] = [
    {
      chart: {
        height: 400,
        type: 'bar',
      },
      series: [
        {
         name: 'Entities',
         data: valori,
        },
      ],
       colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0', '#546E7A', '#D4526E', '#8D3DAF', '#F86624', '#00BFFF'],
      plotOptions: {
          bar: {
            columnWidth: '45%',
            distributed: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        legend: {
          show: false
        },
        xaxis: {
          categories: dati,
          labels: {
            style: {
              colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0', '#546E7A', '#D4526E', '#8D3DAF', '#F86624', '#00BFFF'],  
              fontSize: '12px'
            }
          }
        },
     
      markers: {
        size: 4,
        strokeWidth: 2,
      },
      tooltip: {
        y: {
          formatter: (val: number) => val.toString(),
        },
      },
      yaxis: {
        tickAmount: 7,
        labels: {
          formatter: (val: number, i: number) => {
            if (i % 2 === 0) {
              return val.toString();
            } else {
              return '';
            }
          },
        },
      },
    },
  ];
    
  return charts;
  }
}
